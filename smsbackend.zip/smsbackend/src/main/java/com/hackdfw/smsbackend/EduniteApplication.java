package com.hackdfw.smsbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduniteApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduniteApplication.class, args);
	}

}
