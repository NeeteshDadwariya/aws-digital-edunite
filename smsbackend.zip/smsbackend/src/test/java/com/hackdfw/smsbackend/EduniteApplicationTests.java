package com.hackdfw.smsbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduniteApplicationTests {

	@Test
	void contextLoads() {
	}

}
